# Vulnerability Audit Summary

This document provides a summary of the vulnerability audit conducted on the project. It includes insights from various code analysis tools and image scanning reports.

## Code Analysis

### Dependency Analysis

#### :package: **pip-audit**
- No vulnerabilities detected.

### **bandit report** -> Run metrics:

- **Total issues (by severity)**:
    - Undefined: ![undefined](https://img.shields.io/badge/undefined-0-lightgrey)
    - Low: ![low](https://img.shields.io/badge/low-5-fce1a9)
    - Medium: ![medium](https://img.shields.io/badge/medium-8-fbb552)
    - High: ![high](https://img.shields.io/badge/high-0-e25d68)

---

- **Total issues (by confidence)**:
    - Undefined: ![undefined](https://img.shields.io/badge/undefined-0-lightgrey)
    - Low: ![low](https://img.shields.io/badge/low-8-fce1a9)
    - Medium: ![medium](https://img.shields.io/badge/medium-0-fbb552)
    - High: ![high](https://img.shields.io/badge/high-5-e25d68)

#### :package: **Safety Scan**

**General Scan Details**:

| **Detail**               | **Value**                                                                                                   |
|--------------------------|-------------------------------------------------------------------------------------------------------------|
| **Scan Type**             | Scan (Vulnerability Scan)                                                                                   |
| **Stage**                 | Development                                                                                                 |
| **Vulnerabilities**                 | Not found                                                                                                 |


---

### Static Code Analysis (SAST)

#### :package: **semgrep**
- No vulnerabilities detected.

---

## Image Analysis


#### :package: **Docker Scout CVE Report**
- **Image stored for indexing**: ✅
- **Indexed 1002 packages**: ✅
- **Detected vulnerable packages**: ✗ 
  - 17 vulnerable packages with a total of 28 vulnerabilities



| **package** | Image Reference (`assistant:latest`) |
|------------|------------------------------------------------------------------------|
| **vulnerabilities** | ![critical: 0](https://img.shields.io/badge/critical-0-lightgrey) ![high: 2](https://img.shields.io/badge/high-2-e25d68) ![medium: 2](https://img.shields.io/badge/medium-2-fbb552) ![low: 24](https://img.shields.io/badge/low-24-fce1a9) |
| **size** | 1.1 GB |
| **packages** | 1002 |
