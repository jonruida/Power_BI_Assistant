#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Authors: SDG DS unit
"""
Agent module for simulating backend interactions with reports and queries.

This module defines the BackendUser class, which interacts with a backend system 
to test various endpoints, including querying reports and generating new reports.
It uses Locust for load testing and performs operations like fetching report IDs, 
fetching available dates for reports, and submitting queries to a backend service.
"""

import json
import logging
import random

from locust import HttpUser, between, task

# Configuración de logging
logging.basicConfig(
    filename="logs/locust.log",
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s",
)


class BackendUser(HttpUser):
    """
    A class that simulates a user interacting with the backend system.

    The BackendUser class performs tasks like querying reports, generating new reports,
    and interacting with various endpoints of the backend system. It is designed to
    simulate user behavior using Locust's load testing framework.

    Attributes:
        wait_time (between): Time between each simulated user action.
        host (str): Host URL for the backend system.
        api_url (str): URL for querying data.
        reports_url (str): URL for fetching available reports.
        configurations (list): List of report configurations.
    """

    wait_time = between(1, 3)  # Time between each task
    host = "http://localhost:5001"

    # Endpoint URLs
    api_url = "/query"
    reports_url = "/get_reports"

    # Available configurations for reports
    configurations = [
        "Max Speed",  # Quickest configuration
        "Efficient",  # Balanced configuration
        "Optimized",  # Current configuration
        "High Precision",  # High accuracy configuration
        "Max Accuracy",  # Most precise configuration
    ]

    def string_to_int_ascii(self, s: str) -> int:
        """
        Converts a string to the sum of its ASCII values.

        Args:
            s (str): Input string.

        Returns:
            int: Sum of ASCII values of the characters in the string.
        """
        return sum(ord(char) for char in s)

    def get_informs(self):
        """
        Fetches the list of available report IDs.

        Returns:
            list: List of report IDs, with a default value if an error occurs.
        """
        try:
            response = self.client.get(self.reports_url)
            if response.status_code == 200:
                informs = response.json().get("report_ids", [])
                logging.info(f"Obtained informs successfully: {informs}")
            else:
                logging.warning(
                    f"Failed to get informs: {response.status_code}"
                )
                informs = ["Error al obtener informes"]
            informs.insert(0, "Todos los informes")
            return informs
        except Exception as e:
            logging.error(f"Error in get_informs: {e}")
            return ["Error al obtener informes"]

    def get_dates_by_id(self, report_id_int):
        """
        Fetches available dates for a specific report.

        Args:
            report_id_int (int): The report ID to fetch dates for.

        Returns:
            list: List of dates, or an empty list if an error occurs.
        """
        params = {"id": report_id_int}
        try:
            response = self.client.get("/get_dates_by_id", params=params)
            fechas = response.json().get("dates", [])
            data = json.loads(fechas)
            dates = data.get("dates", [])
            logging.info(
                f"Obtained dates for report_id {report_id_int}: {dates}"
            )
            return dates
        except Exception as e:
            logging.error(
                f"Error in get_dates_by_id for report_id {report_id_int}: {e}"
            )
            return []

    @task(1)
    def query(self):
        """
        Simulates a query to the backend system.

        This task sends a query to the backend, including a randomly selected
        configuration and a report ID from the list of available reports.
        """
        informs = self.get_informs()
        payload = {
            "query": "¿Cuál es el KPI más relevante?",
            "configuration": random.choice(self.configurations),
            "informe_seleccionado": informs[0],
            "informes_disponibles": informs,
        }
        response = self.client.post(self.api_url, json=payload)
        if response.status_code == 200:
            logging.info(f"Query executed successfully: {payload}")
        else:
            logging.error(f"Error in /query: {response.status_code}")

    @task(1)
    def generate_report(self):
        """
        Simulates the generation of a report by sending a request to the backend.

        This task first fetches available dates for a report and then sends a request
        to generate the report with the selected date and configuration.
        """
        informs = self.get_informs()
        report_id_int = self.string_to_int_ascii(s=informs[3])
        dates = self.get_dates_by_id(report_id_int)
        if dates:
            payload = {
                "report_id": informs[3],
                "fecha": dates[0],
                "formato": "resumido",
            }
            response = self.client.post("/generate_report", json=payload)
            if response.status_code == 200:
                logging.info(f"Report generated successfully: {payload}")
            else:
                logging.error(
                    f"Error in /generate_report: {response.status_code}"
                )
        else:
            logging.error("No dates available to generate the report.")
