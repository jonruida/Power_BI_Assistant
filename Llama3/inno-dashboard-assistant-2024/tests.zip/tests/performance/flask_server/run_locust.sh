#!/bin/bash

# Ejecutar Locust con 10 usuarios (puedes ajustar este valor)
echo "Ejecutando Locust con 10 usuarios..."
locust -f locust_file.py --users 10 --spawn-rate 0.1 --run-time 300s  --csv=./results/locust_report

