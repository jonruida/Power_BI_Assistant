#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Author: [Your Name]
"""
This script performs automated query processing for a set of predefined questions. 

It interacts with a PowerBI Assistants Flask API Backend server to send queries and records the results in markdown files, 
including response times for each configuration. It's result helps to evaluate and compare performance of diferente working modes.

In order to use the 6 option (All configuration modes), it's necessary to modify temporarily de source code. It's necessary to 
disable agent's memory by setting k parameter to 0, in agente_executor's memory definition, in src.services.agent.core modeule.  
"""

import json
import os
import time
from datetime import datetime

import requests
from qdrant_client import QdrantClient

# Define constants
QUESTIONS_FILE = "questions.json"  # Path to the JSON file with questions
API_URL = "http://127.0.0.1:5001/query"  # Flask API endpoint


def load_questions() -> dict:
    """
    Loads the list of questions from the specified JSON file.

    Returns:
        dict: The parsed JSON data containing the questions and their categories.
    """
    with open(QUESTIONS_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def get_informs() -> list:
    """
    Fetches the available reports from the Flask API.

    Returns:
        list: A list of report IDs, with "Todos los informes" as the first option.
    """
    response = requests.get("http://localhost:5001/get_reports")
    if response.status_code == 200:
        informs = response.json().get("report_ids", [])
    else:
        informs = ["Error al obtener informes"]
    informs.insert(0, "Todos los informes")
    return informs


def select_configuration() -> str:
    """
    Prompts the user to select a configuration for query processing.

    Returns:
        str: The selected configuration. If invalid input is given, returns 'Optimized'.
    """
    configurations = [
        "Max Speed",  # Quickest configuration
        "Efficient",  # Balanced configuration
        "Optimized",  # Current configuration
        "High Precision",  # High accuracy configuration
        "Max Accuracy",  # Most precise configuration
    ]

    print("\nSeleccione una configuración:")
    for i, config in enumerate(configurations, 1):
        print(f"{i}. {config}")
    print("6. Todos")

    choice = input("Ingrese el número de la configuración deseada: ")
    try:
        choice = int(choice)
        if choice == 6:
            return "Todos"
        elif 1 <= choice <= len(configurations):
            return configurations[choice - 1]
        else:
            print("Selección no válida. Usando 'Optimized'.")
            return "Optimized"
    except ValueError:
        print("Selección no válida. Usando 'Optimized'.")
        return "Optimized"


def send_questions(configuration: str, informs: list):
    """
    Sends the questions to the Flask API and records the responses,
    including response times, in a markdown file.

    Args:
        configuration (str): The selected configuration for query processing.
        informs (list): A list of available reports.
    """
    data = load_questions()
    categories = data["categories"]
    time.sleep(120)

    # Set up result file
    current_date = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"./results/result_{configuration}_{current_date}.md"
    os.makedirs(os.path.dirname(filename), exist_ok=True)

    summary_table = {}  # To store response times for each configuration

    with open(filename, "w", encoding="utf-8") as file:
        file.write(
            f"# Resultados de consulta - {configuration} - {current_date}\n\n"
        )

        if configuration == "Todos":
            # Iterate over all configurations if 'Todos' is selected
            configurations = [
                "Max Speed",
                "Efficient",
                "Optimized",
                "High Precision",
                "Max Accuracy",
            ]
            for config in configurations:
                summary_table[config] = (
                    []
                )  # Initialize list for the current configuration
                qdrant_client = QdrantClient("localhost", port=6333)
                file.write(f"## Configuración: {config}\n")
                for category, questions in categories.items():
                    file.write(f"### Categoría: {category}\n")
                    for idx, question in enumerate(questions, start=1):
                        payload = {
                            "query": question,
                            "configuration": config,
                            "informe_seleccionado": informs[0],
                            "informes_disponibles": informs,
                        }

                        start_time = time.time()  # Start timer
                        try:
                            response = requests.post(API_URL, json=payload)
                            end_time = time.time()  # End timer

                            response_time = end_time - start_time
                            summary_table[config].append((idx, response_time))

                            if response.status_code == 200:
                                result = response.json()["response"]
                                file.write(f"**Pregunta**: {question}\n")
                                file.write(f"**Respuesta**: {result}\n")
                                file.write(
                                    f"**Tiempo de respuesta**: {response_time:.2f} segundos\n\n"
                                )
                                print(f"Pregunta: {question}")
                                print(f"Respuesta: {result}\n")
                            else:
                                file.write(f"**Pregunta**: {question}\n")
                                file.write(f"**Error**: {response.text}\n")
                                file.write(
                                    f"**Tiempo de respuesta**: {response_time:.2f} segundos\n\n"
                                )
                                print(
                                    f"Error al procesar la pregunta: {question}"
                                )
                                print(f"Detalle: {response.text}\n")
                        except Exception as e:
                            end_time = time.time()
                            response_time = end_time - start_time
                            summary_table[config].append((idx, response_time))

                            file.write(f"**Pregunta**: {question}\n")
                            file.write(f"**Error**: {str(e)}\n")
                            file.write(
                                f"**Tiempo de respuesta**: {response_time:.2f} segundos\n\n"
                            )
                            print(f"Error enviando la pregunta: {question}")
                            print(str(e))
        else:
            # Process a single configuration
            summary_table[configuration] = []
            for category, questions in categories.items():
                file.write(f"## Categoría: {category}\n")
                for idx, question in enumerate(questions, start=1):
                    payload = {
                        "query": question,
                        "configuration": configuration,
                        "informe_seleccionado": informs[0],
                        "informes_disponibles": informs,
                    }

                    start_time = time.time()
                    try:
                        response = requests.post(API_URL, json=payload)
                        end_time = time.time()

                        response_time = end_time - start_time
                        summary_table[configuration].append(
                            (idx, response_time)
                        )

                        if response.status_code == 200:
                            result = response.json()["response"]
                            file.write(f"**Pregunta**: {question}\n")
                            file.write(f"**Respuesta**: {result}\n")
                            file.write(
                                f"**Tiempo de respuesta**: {response_time:.2f} segundos\n\n"
                            )
                            print(f"Pregunta: {question}")
                            print(f"Respuesta: {result}\n")
                                # Añadir espera de 1 minuto
                            print(f"Esperando 1 minuto antes de procesar la siguiente pregunta...")
                            time.sleep(120)
                        else:
                            file.write(f"**Pregunta**: {question}\n")
                            file.write(f"**Error**: {response.text}\n")
                            file.write(
                                f"**Tiempo de respuesta**: {response_time:.2f} segundos\n\n"
                            )
                            print(f"Error al procesar la pregunta: {question}")
                            print(f"Detalle: {response.text}\n")
                    except Exception as e:
                        end_time = time.time()
                        response_time = end_time - start_time
                        summary_table[configuration].append(
                            (idx, response_time)
                        )

                        file.write(f"**Pregunta**: {question}\n")
                        file.write(f"**Error**: {str(e)}\n")
                        file.write(
                            f"**Tiempo de respuesta**: {response_time:.2f} segundos\n\n"
                        )
                        print(f"Error enviando la pregunta: {question}")
                        print(str(e))

        # Write summary table at the end
        file.write("\n## Tabla Resumen de Tiempos\n")
        headers = "| Pregunta | " + " | ".join(summary_table.keys()) + " |\n"
        file.write(headers)
        file.write(
            "|----------" + "|----------" * len(summary_table.keys()) + "|\n"
        )

        max_questions = max(
            len(questions) for questions in summary_table.values()
        )
        for i in range(1, max_questions + 1):
            row = f"| {i} "
            for config in summary_table.keys():
                time_taken = next(
                    (t for q, t in summary_table[config] if q == i), "-"
                )
                row += f"| {time_taken:.2f} " if time_taken != "-" else "| - "
            row += "|\n"
            file.write(row)


if __name__ == "__main__":
    configuration = select_configuration()
    informs = get_informs()
    send_questions(configuration, informs)