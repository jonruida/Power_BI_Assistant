# Flujo Completo de combined.py

```mermaid
graph TD;
    A[Iniciar Proceso] --> B[Cargar Variables de Entorno];
    B --> C[Convertir PDF a Imágenes];
    C --> D[Convertir Imágenes a Base64];
    D --> E[Crear Mensaje para OpenAI];
    E --> F[Llamar a la API de OpenAI];
    F --> G[Recibir Respuesta de OpenAI];
    G --> H{Advertencias en la Respuesta?};
    
    H -- No --> I[Finalizar Proceso];
    H -- Sí --> J[Convertir PDF a Texto];
    
    J --> K[Enviar Páginas del PDF a OpenAI];
    K --> L[Recibir Respuesta de OpenAI];
    
    L --> M[Guardar Resultados en JSON];
    M --> N[Finalizar Proceso];
    
    subgraph Proceso_Imágenes;
    C --> D --> E --> F --> G;
    end;
    
    subgraph Proceso_PDF;
    J --> K --> L;
    end;




```


## Carga de Variables de Entorno:

- Se utiliza el archivo `.env` para cargar la clave de API de OpenAI en la variable de entorno `OPENAI_API_KEY`.

## Procesamiento de Imágenes:

- Se proporciona una lista de rutas de imágenes (`image_paths`), que representan las páginas del PDF exportadas como imágenes.
- Cada imagen se convierte a formato base64 para ser enviada a la API de OpenAI.
- Se crea un mensaje estructurado en formato JSON que incluye una descripción del informe (KPIs, visualizaciones, tablas) y las imágenes codificadas.

## Llamada a la API de OpenAI para Procesar Imágenes:

- Se envían las imágenes junto con las instrucciones detalladas a la API de OpenAI para su análisis.
- La API devuelve un análisis preliminar de los KPIs, visualizaciones y tablas presentes en las imágenes.

## Verificación de Advertencias:

- El sistema verifica si la respuesta contiene advertencias, especialmente si hay tablas incompletas.
- Si se detectan tablas incompletas, el proceso continúa con la extracción de texto del PDF.

## Conversión de PDF a Texto:

- Si es necesario (por ejemplo, si hay advertencias de tablas incompletas), se procesa el PDF completo.
- Cada página del PDF se convierte en texto utilizando `PyPDFLoader` en el modo de extracción 'layout'.
- El texto de cada página se envía nuevamente a OpenAI para su análisis detallado.

## Análisis del Contenido del PDF:

- Se analiza cada página del PDF en busca de KPIs, gráficos, tablas, anomalías y cualquier otro dato relevante que no se haya capturado en las imágenes.
- El sistema almacena los resultados del PDF como un archivo JSON.

## Guardar Resultados:

- Si se procesó el PDF, los resultados se guardan en un archivo JSON para su posterior análisis o referencia.

## Finalización del Proceso:

- Si no se encontraron advertencias, el proceso finaliza tras el análisis de las imágenes.
- Si se procesó el PDF, se guarda el análisis completo (imágenes + texto del PDF) para obtener una visión integral del dashboard.
