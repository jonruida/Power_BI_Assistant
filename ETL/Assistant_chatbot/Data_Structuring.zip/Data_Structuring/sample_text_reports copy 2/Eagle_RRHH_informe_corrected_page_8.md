Esta página del informe de Power BI, correspondiente al cuadro de mando de recursos humanos, proporciona una visión integral sobre la situación laboral de la organización a través de diversos indicadores clave de rendimiento (KPIs), gráficos y tablas. Se enfoca en el análisis de la estabilidad del empleo, la diversidad en la fuerza laboral y las tendencias de contratación.

En la sección de KPIs, se presentan varios indicadores que reflejan aspectos críticos del personal. El KPI "Nº Indefinidos" muestra un total de 477 empleados con contratos indefinidos, lo que sugiere un nivel considerable de estabilidad laboral en la organización. Por otro lado, el "Nº Sustitución" indica que hay 160 contratos de sustitución, lo que resalta la necesidad de cubrir vacantes temporales. El "Índice indefinidos %" se sitúa en un 75 %, lo que significa que una gran parte de la fuerza laboral tiene contratos indefinidos, lo que es un signo positivo de estabilidad. El KPI de "Absenteísmo" se encuentra en un 2.30 %, proporcionando una visión sobre la fiabilidad de la fuerza laboral. Además, el KPI de "Discapacidad" muestra que solo el 0.04 % de los empleados tienen discapacidad, lo que podría señalar una oportunidad para mejorar la diversidad e inclusión. En términos de beneficios económicos, el "Importe bonificaciones" asciende a 139.273 €, lo que refleja el apoyo financiero que la organización brinda a sus empleados. La fuerza laboral total se compone de 666 empleados, de los cuales 275 tienen contratos temporales, y 323 contratos son de muy corta duración (1 a 6 días). Finalmente, el "Índice de contratos %" es del 26.75 %, indicando una proporción significativa de contratos en relación con el tamaño total de la fuerza laboral.

En cuanto a los gráficos, se presenta un gráfico de líneas titulado "Nº Empleados indefinidos por año y mes". Este gráfico muestra una tendencia creciente en el número de empleados indefinidos desde enero de 2018 hasta octubre de 2019. Los datos revelan que el número de empleados indefinidos ha aumentado de 250 en enero de 2018 a 370 en octubre de 2019, lo que indica una mejora continua en la estabilidad del empleo a lo largo del tiempo. Esta tendencia positiva se alinea con los KPIs mostrados, destacando que la organización ha estado incrementando su número de empleados con contratos indefinidos, lo que es un indicador favorable para la gestión de recursos humanos.

La tabla titulada "Centro de trabajo" proporciona un desglose detallado de los empleados indefinidos por centro de trabajo. En esta tabla, se puede observar que el "Centro de trabajo 5" tiene la mayor cantidad de empleados indefinidos con 80, seguido por el "Centro de trabajo 6" con 77. La tabla también muestra que todos los centros de trabajo han mantenido un cambio porcentual de 0.00 % respecto al mes anterior y al año anterior, lo que sugiere una estabilidad en la distribución de empleados indefinidos en los diferentes centros.

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 8 del Eagle_RRHH':
- metadata:
    Title: "Resumen Cuadro de Mando Página 8",
    Report_Id: "Eagle_RRHH",
    Elements: ["KPIs", "Gráficos", "Tablas"],
    insertion_year: 2024,
    insertion_month: 9,
    insertion_day: 23,
    page: 8