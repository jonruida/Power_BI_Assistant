En esta página del informe "Eagle_Ventas", se presentan indicadores clave de desempeño (KPIs) y visualizaciones gráficas que brindan una visión integral sobre la situación actual de las facturas y el backlog de la empresa en el año en curso. A continuación, se detallan los KPIs, gráficos y tablas que componen este cuadro de mando.

Los KPIs detectados ofrecen una visión clara del rendimiento financiero de la empresa. El primer KPI, titulado "Invoice CY", muestra un valor de 1.658.553, con una referencia de -98.48%. Esta cifra indica una caída significativa del 98.48% en comparación con períodos anteriores, lo que sugiere un descenso alarmante en la facturación actual. Por otro lado, el KPI "Backlog CY" reporta un valor de 22.419.351, sin referencia adicional, lo que implica que hay una cantidad considerable de facturas pendientes por procesar, destacando la necesidad de atención en la gestión de estos documentos.

En cuanto a las visualizaciones, se presentan tres gráficos en formato de gráfico circular que ilustran la distribución de las facturas del año en curso. El primer gráfico, titulado "Top 5 Invoice CY by Product Family", muestra la participación de diferentes familias de productos en el total de facturas. Las métricas mostradas incluyen "Breakaway Mobile", "Battery mobile", "Other Com.", "Human Generated" y "Miscellaneous", con valores de 12.58%, 11%, 13.78%, 33.66% y 28.98%, respectivamente. Aquí, se observa que la categoría "Human Generated" representa la mayor parte, con un 33.66%, lo que sugiere que este tipo de productos es el más demandado en el mercado actual.

El segundo gráfico, "Top 5 Invoice CY by Customer Class", también en formato de gráfico circular, categoriza las facturas según la clase de cliente. Las métricas incluyen "Foreigner", "Intra-Community EU", "Intra-Community" y "Foreigner Group", con valores de 41.87%, 5.9%, 24.15% y 13.23%. Este gráfico revela que los clientes extranjeros constituyen la mayor parte de las facturas, representando un 41.87%, lo que podría indicar una fuerte dependencia de este segmento de clientes.

Finalmente, el gráfico titulado "Top 5 Invoice CY by Customers" muestra la contribución de los principales clientes a las facturas del año en curso. Las métricas son "Customer 775", "Customer 788", "Customer 774" y "Customer 1664", con valores de 13.23%, 35.36%, 17.54% y 18.98%. En este caso, "Customer 788" se destaca como el cliente más significativo, aportando un 35.36% del total de facturas, lo que resalta su importancia en la estrategia comercial de la empresa.

Complementando la información visual, se incluye una tabla titulada "Invoice Year to Day", que compara las facturas del año actual con las de los tres años anteriores. Los datos muestran que el total de facturas del año actual es de 1.658.553, en contraste con 109.054.000 del año anterior, 111.824.000 del anterior y 118.282.000 del año anterior a ese. Esta comparación resalta una disminución drástica en las facturas del año actual, lo que refuerza la preocupación manifestada en el KPI de "Invoice CY".

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 1 del Eagle_Ventas':
- metadata:
    Title: 'KPIs y Visualizaciones de Facturación',
    Report_Id: 'Eagle_Ventas',
    Elements: ['Invoice CY', 'Backlog CY', 'Top 5 Invoice CY by Product Family', 'Top 5 Invoice CY by Customer Class', 'Top 5 Invoice CY by Customers', 'Invoice Year to Day'],
    insertion_year: 2024,
    insertion_month: 9,
    insertion_day: 23,
    page: 1