En esta página del informe correspondiente al cuadro de mando de RRHH, se presentan indicadores clave de rendimiento (KPIs), un gráfico que ilustra la evolución de los costos por absentismo y una tabla que detalla los costos asociados a cada centro de trabajo. Esta información es crucial para entender el impacto financiero del absentismo en la organización y para tomar decisiones informadas sobre la gestión del personal.

Los KPIs detectados en esta página ofrecen una visión clara del costo total relacionado con el absentismo y otros aspectos financieros del personal. El primer KPI, titulado "Importe", tiene un valor de 372.787 €, y representa el costo total en nómina asociado al absentismo, lo que indica un impacto financiero significativo en la organización. A continuación, el KPI "Coste personal total" muestra un valor de 16.236,96 €, reflejando el gasto total en compensación de empleados. El "Índice Absentismo" se sitúa en un 2,30%, lo que mide la tasa de absentismo en relación con la plantilla total. Otro KPI relevante es el "Complemento IT", que asciende a 121.378 €, mostrando la compensación adicional para empleados en baja por enfermedad, lo que evidencia el compromiso de la empresa con su personal en situaciones de salud. Además, el KPI "Importe bonificaciones" indica un total de 139.273 €, destacando los incentivos financieros adicionales que se ofrecen a los empleados. Finalmente, el KPI "# Empleados" señala que la organización cuenta con 666 empleados, proporcionando un contexto sobre el tamaño de la fuerza laboral.

El gráfico titulado "Importe por año y mes" es un gráfico de líneas que muestra la tendencia de los costos de absentismo a lo largo del tiempo, segmentado por mes y año. Este gráfico destaca picos en ciertos meses de 2018 y principios de 2019, lo que sugiere que hubo periodos de mayor costo por absentismo. Los valores presentados en el gráfico, que incluyen montos como 10.000 €, 15.000 €, 20.000 € y 25.000 €, permiten visualizar claramente estas fluctuaciones y ayudan a identificar los meses con mayores impactos financieros.

La tabla titulada "Centro de trabajo" proporciona una visión detallada de los costos de absentismo por cada centro de trabajo. Las columnas incluyen "Centro de trabajo", "Importe", "Mes anterior Dif %" y "Mes año anterior Dif %". Cada fila representa un centro de trabajo, mostrando costos que varían desde 4.506,91 € hasta 106.835,11 €. Es importante destacar que, a pesar de que se presentan los datos de costos, todas las comparaciones con el mes anterior y el mismo mes del año anterior indican una variación del 0,00 %, lo que sugiere que no ha habido cambios significativos en estos costos en el último periodo analizado.

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 5 del Eagle_RRHH':
- metadata:
    Title: 'Resumen Cuadro de Mando Página 5 del Eagle_RRHH',
    Report_Id: 'Eagle_RRHH',
    Elements: ['KPIs', 'charts', 'tables'],
    insertion_year: 2024,
    insertion_month: 9,
    insertion_day: 23,
    page: 5