En esta página del informe de Power BI, se presenta un análisis exhaustivo de los indicadores clave de rendimiento (KPIs) relacionados con las vacaciones y la gestión de recursos humanos en la organización. Los KPIs proporcionan una visión clara sobre el uso de días de vacaciones, los costos asociados y la situación del personal, lo cual es fundamental para la toma de decisiones estratégicas en la gestión del talento humano.

Los KPIs detectados incluyen una variedad de métricas que reflejan el estado actual de las vacaciones en la empresa. El KPI titulado "Nº días devengados" muestra un total de 125.873 días, lo que indica la acumulación de días de vacaciones por parte de los empleados. El "Coste días devengados" asciende a 5.677.198,1 €, lo que resalta el impacto financiero de las políticas de vacaciones. Además, se reporta un "Nº días disfrutados" de 14.459, lo que sugiere un nivel de compromiso con las políticas de descanso. En términos de costos, el "Coste días disfrutados" es de 652.126,7 €, lo que proporciona una perspectiva sobre el gasto en días de vacaciones utilizados. Otros KPIs relevantes incluyen el "Índice de sustitución" que se sitúa en 56,57 %, lo que refleja la estabilidad del personal, y un "Absenteísmo" del 2,30 %, que ofrece indicios sobre la asistencia de los empleados. También se observa un "Nº días contratados" de 8.180, y un "Coste contratos sueldos" de 372.142 €, lo que es clave para entender los gastos en nómina.

La sección de gráficos incluye un análisis visual titulado "Nº días devengados de vacaciones por año y mes", representado a través de un gráfico de líneas. Este gráfico muestra la tendencia de los días de vacaciones acumulados a lo largo de los meses y años, permitiendo identificar picos en el uso de días de vacaciones. Los valores en el gráfico indican que hay períodos específicos donde la acumulación de días es notablemente alta, sugiriendo patrones estacionales en el comportamiento de las solicitudes de vacaciones. Este tipo de visualización es crucial para la planificación de recursos y la gestión de ausencias, ya que permite a los gerentes prever y gestionar mejor los períodos de alta demanda de días de descanso.

En la sección de tablas, se presenta un análisis detallado en la tabla titulada "Centro de trabajo 5", que desglosa los días de vacaciones devengados por puesto de trabajo. Esta tabla incluye columnas que muestran el "Puesto de trabajo", "Nº días devengados de vacaciones", y las variaciones porcentuales respecto al mes anterior y al mismo mes del año anterior. Los datos indican que el "Puesto de trabajo 2" tiene una acumulación de 12.178,39 días, lo que representa un punto focal en la gestión de vacaciones, mientras que otros puestos como el "Puesto de trabajo 142" y "Puesto de trabajo 3" muestran cifras de 2.318,83 y 688,72 días respectivamente. La tabla proporciona una base sólida para el análisis de la gestión de recursos humanos y la identificación de áreas que podrían requerir atención especial en términos de planificación de vacaciones.

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 7 del Eagle_RRHH':
- metadata:
    Title: 'Resumen Cuadro de Mando Página 7 del Eagle_RRHH',
    Report_Id: 'Eagle_RRHH',
    Elements: ['KPIs', 'charts', 'tables'],
    insertion_year: 2024,
    insertion_month: 9,
    insertion_day: 23,
    page: 7