La página 1 del informe "Eagle_RRHH" presenta un cuadro de mando centrado en indicadores clave de recursos humanos, proporcionando una visión general de métricas fundamentales que afectan el desempeño del personal en la organización. Este resumen se enfoca en los KPIs detectados y su relevancia en el contexto actual del reporte.

En cuanto a los KPIs, se han identificado varios indicadores significativos. El primero es "Masa Salarial", cuyo valor es "Valor visible". Este KPI refleja el gasto total en salarios durante el período analizado, lo que permite a la organización evaluar su inversión en recursos humanos. A continuación, se presenta el KPI "Absentismo", que también tiene un valor de "Valor visible". Este indicador mide el porcentaje de ausencias de los empleados, un factor crítico que puede influir en la productividad general. Otro KPI importante es "Manhours", que representa las horas totales trabajadas en el período, con un valor igualmente indicado como "Valor visible". Este dato es esencial para entender la capacidad de trabajo de la fuerza laboral. Además, se incluye el KPI "Vacaciones", que indica el total de días de vacaciones tomados por los empleados, y "Contratos", que muestra el número de contratos de empleo activos, ambos con el mismo valor de "Valor visible". Por último, se presenta "Otra Información", que proporciona datos adicionales relevantes sobre recursos humanos, también con un valor de "Valor visible". Aunque todos los KPIs tienen un valor visible, no se indican comparaciones o variaciones en esta sección.

Respecto a los gráficos, no se han detectado elementos gráficos en esta página del informe. Esto significa que la presentación de datos se limita a los KPIs y la tabla que resume los indicadores.

La tabla titulada "Resumen de Indicadores" ofrece una visión consolidada de los KPIs mencionados, organizando la información en columnas que incluyen "Indicador" y "Valor". Las filas de la tabla enumeran cada KPI junto con su valor correspondiente, facilitando una rápida referencia a las métricas clave de recursos humanos. Esta tabla es fundamental para entender el estado actual de los indicadores y su impacto en la gestión del personal.

Finalmente, se incluye la sección de metadatos que resume la información clave del informe:

Título: 'Resumen Cuadro de Mando Página 1 del Eagle_RRHH':
- metadata:
    Title: Resumen Cuadro de Mando Página 1,
    Report_Id: Eagle_RRHH,
    Elements: [Masa Salarial, Absentismo, Manhours, Vacaciones, Contratos, Otra Información],
    insertion_year: 2024,
    insertion_month: 09,
    insertion_day: 23,
    page:  1