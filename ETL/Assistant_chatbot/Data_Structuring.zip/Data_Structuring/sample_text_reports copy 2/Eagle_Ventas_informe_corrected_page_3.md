La página 3 del reporte "Eagle_Ventas" se centra en el análisis del backlog, proporcionando una visión clara de la situación actual y comparativa de los pedidos no cumplidos. A través de indicadores clave de rendimiento (KPIs), gráficos y tablas, se ofrece una comprensión integral de cómo se distribuyen los pedidos pendientes tanto en términos geográficos como por clase de cliente.

En cuanto a los KPIs detectados, se destacan dos indicadores principales. El primero es el "Backlog Current Year (CY)", que muestra un valor de 22.419.351 unidades. Este KPI es fundamental, ya que representa el total de pedidos pendientes para el año actual hasta la fecha, lo que es crucial para la planificación de la producción y el cumplimiento de pedidos. En comparación, el "Backlog Previous Year (FY)" se sitúa en 719.391 unidades. Este segundo KPI proporciona un punto de referencia que permite evaluar el rendimiento actual en relación con el año anterior, destacando una variación significativa en el backlog actual frente al del año pasado.

La sección de gráficos complementa la información presentada en los KPIs, comenzando con un mapa titulado "Backlog by Country". Este gráfico, que utiliza una representación geográfica, muestra la distribución del backlog total por país, destacando las regiones con mayores volúmenes de pedidos pendientes. Los valores representados incluyen regiones como América del Norte, Europa, África, Asia y Oceanía, lo que permite identificar claramente las áreas donde se concentra la demanda no satisfecha.

Además, se presenta un gráfico de tipo "Pie Chart" titulado "Backlog by Continent". Este gráfico ilustra la distribución del backlog segmentado por continentes, revelando que Europa tiene el mayor volumen de pedidos pendientes con 11.358.768 unidades, seguida de América del Norte con 9.353.772 unidades y Asia con 1.200.000 unidades. Esta representación visual resalta la diferencia en el backlog entre las distintas regiones, sugiriendo que las estrategias de cumplimiento pueden necesitar ser adaptadas según la ubicación geográfica de los clientes.

Finalmente, se incluye una tabla titulada "Backlog by Customer Class", que detalla el backlog segmentado por diferentes clases de clientes. La tabla muestra que los clientes extranjeros tienen la mayor contribución al backlog con 9.353.772 unidades, seguidos por el "Customer 2495" con 3.063.626 unidades. Esta información es valiosa para entender cómo cada clase de cliente impacta en el total del backlog, lo que puede ayudar a priorizar esfuerzos en el cumplimiento de pedidos.

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 3 del Eagle_Ventas':
- metadata:
    Title: [Resumen Cuadro de Mando Página 3 del Eagle_Ventas],
    Report_Id: [Eagle_Ventas],
    Elements: [Backlog Current Year (CY), Backlog Previous Year (FY), Backlog by Country, Backlog by Continent, Backlog by Customer Class],
    insertion_year: [2024],
    insertion_month: [09],
    insertion_day: [23],
    page: 3