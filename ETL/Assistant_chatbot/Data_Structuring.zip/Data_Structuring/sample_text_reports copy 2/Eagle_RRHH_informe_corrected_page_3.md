En esta página del informe de Power BI correspondiente al cuadro de mando "Eagle_RRHH", se presenta un análisis exhaustivo de los gastos relacionados con sueldos y salarios, así como otros indicadores clave de desempeño (KPIs) que reflejan la situación financiera y de recursos humanos de la organización. A través de KPIs, gráficos y tablas, se proporciona una visión clara del estado actual de la nómina y su evolución.

Los KPIs detectados en esta página son fundamentales para entender la estructura de costos laborales. El primer KPI, "Sueldos y Salarios", tiene un valor de 12.398.128 €, lo que indica el total gastado en salarios, reflejando la carga financiera que representa la nómina para la empresa. Otro KPI relevante es "Atrasos", que muestra un valor de 190.383 €, sugiriendo problemas potenciales en la gestión de pagos. Además, el KPI de "Bonus" reporta 385.528 €, destacando los incentivos adicionales otorgados a los empleados. También se identifican costos por indemnizaciones, donde "Indemn. totales" suma 39.403 €, "Indemn. despido" 27.392 € y "Indemn. finalización" 12.012 €, lo que proporciona una visión clara de los gastos asociados a la terminación de contratos. En cuanto a las obligaciones de seguridad social, el KPI "Coste S.S." se sitúa en 3.838.837 €, y se reportan atrasos en estos pagos por un total de 60.295 €. Finalmente, se observa que el número total de empleados es de 666, con un 75 % de ellos en contratos indefinidos, lo que sugiere un entorno laboral relativamente estable. El absentismo se reporta en un 2,30 % y la tasa de discapacidad es de 0,04 %, lo que también aporta información sobre la inclusión y la asistencia en el lugar de trabajo.

En cuanto a las visualizaciones, se presenta un gráfico titulado "Sueldos y Salarios por año y mes", que es un gráfico de líneas. Este gráfico muestra la evolución de los gastos en salarios a lo largo del tiempo, con métricas que indican "Salaries over time". Los valores representados en el gráfico oscilan entre 350.000 € y 650.000 €, evidenciando un crecimiento gradual en los gastos de nómina desde enero de 2018 hasta julio de 2019. Las fluctuaciones observadas pueden estar relacionadas con contrataciones estacionales o la asignación de bonos, lo que sugiere que la empresa ha experimentado variaciones en su plantilla y en sus políticas de compensación.

Finalmente, se incluye una tabla titulada "Centro de trabajo", que desglosa los gastos en sueldos y salarios por diferentes centros de trabajo. Esta tabla muestra que el total de 12.398.128,09 € se distribuye entre varios centros, destacando que el "Centro de trabajo 5" tiene el mayor gasto con 1.947.438,92 €, seguido por el "Centro de trabajo 6" con 1.898.667,18 €. Las diferencias porcentuales en comparación con el mes anterior y el mismo mes del año anterior son del 0,00 %, lo que indica una estabilidad en los gastos en relación con los períodos comparativos.

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 3 del Eagle_RRHH':
- metadata:
    Title: 'Resumen Cuadro de Mando Página 3 del Eagle_RRHH',
    Report_Id: 'Eagle_RRHH',
    Elements: ['KPIs', 'charts', 'tables'],
    insertion_year: 2024,
    insertion_month: 9,
    insertion_day: 23,
    page: 3