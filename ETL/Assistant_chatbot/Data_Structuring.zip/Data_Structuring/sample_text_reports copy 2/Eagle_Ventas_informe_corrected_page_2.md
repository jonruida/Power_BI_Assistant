La página 2 del reporte "Eagle_Ventas" ofrece una visión integral del desempeño de ventas, centrándose en los cambios significativos en las cifras de ventas de los principales clientes. A través de indicadores clave de rendimiento (KPIs) y visualizaciones gráficas, se analizan tanto los incrementos como las disminuciones en las ventas, proporcionando un contexto valioso para la toma de decisiones.

En cuanto a los KPIs detectados, se presentan dos métricas clave que reflejan el rendimiento de las ventas en comparación con el año anterior. El primer KPI, titulado "Top 30 Increase", muestra un valor de "200.69 mil", haciendo referencia a las cifras del año anterior. Este indicador representa un aumento total en la cantidad de ventas para los 30 principales clientes en comparación con el mismo período del año anterior, lo que sugiere un crecimiento significativo en el rendimiento de ventas. Por otro lado, el KPI "Top 30 Decrease" presenta un valor de "-107.60 mil", también en relación con el año anterior. Este KPI indica una disminución total en las ventas para los mismos 30 clientes, lo que resalta áreas de preocupación que podrían requerir atención adicional.

La sección de gráficos complementa los KPIs al ofrecer una representación visual de los datos. El primer gráfico, titulado "Net Amount YTD vs PYTD by Customer", es un gráfico de barras que compara las cifras de ventas acumuladas hasta la fecha (YTD) del año actual con las del año anterior (PYTD) para cada cliente. Las métricas mostradas incluyen "Invoice CY" y "Invoice PYTD", con valores que varían desde "0.0 mil" hasta "14.1 mil". Este gráfico revela tendencias en el desempeño de ventas, donde se observa que algunos clientes han mantenido o incrementado sus compras, mientras que otros han experimentado caídas notables en sus cifras de ventas.

El segundo gráfico, "Top 30 Increase", también es un gráfico de barras que presenta las métricas de "Invoice CY", "Invoice P1YTD" y "Invoice Dif P1YTD vs CY". Los valores reflejan un incremento de "200.69 mil" en las ventas actuales en comparación con el año anterior, destacando el crecimiento en las ventas de los principales clientes. Este gráfico proporciona una perspectiva clara sobre cómo estos clientes han contribuido al aumento general de las ventas.

Finalmente, el gráfico "Top 30 Decrease" ilustra la disminución en las ventas, mostrando las métricas "Invoice CY", "Invoice P1YTD" y "Invoice Dif CY vs P1YTD". Con un valor de "-107.60 mil", este gráfico resalta las discrepancias en las ventas actuales en comparación con el año anterior, enfatizando los riesgos potenciales asociados con la pérdida de ventas en ciertos clientes clave.

La tabla "Customer Sales Data" complementa estos gráficos al ofrecer datos detallados sobre cada cliente, incluyendo las cifras de ventas actuales y del año anterior, así como la diferencia entre ambas. Esta tabla permite una comprensión más profunda de las tendencias observadas en los gráficos, proporcionando un contexto adicional sobre el rendimiento de ventas de cada cliente.

Sección de metadatos:
Título: 'Resumen Cuadro de Mando Página 2 del Eagle_Ventas':
- metadata:
    Title: "Resumen Cuadro de Mando Página 2",
    Report_Id: "Eagle_Ventas",
    Elements: ["Top 30 Increase", "Top 30 Decrease", "Net Amount YTD vs PYTD by Customer", "Top 30 Increase", "Top 30 Decrease", "Customer Sales Data"],
    insertion_year: 2024,
    insertion_month: 9,
    insertion_day: 23,
    page: 2