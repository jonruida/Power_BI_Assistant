import os
import re

def clean_json_file(file_path):
    print(f"[INFO] Cleaning JSON file: {file_path}")
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            cleaned_content = re.sub(r'```json|```', '', content)
            cleaned_content = cleaned_content.strip().strip('"')
            cleaned_content = cleaned_content.replace('\\n', ' ').strip()
            cleaned_content = cleaned_content.replace('\\', '').strip()


        # Imprimir el contenido limpio para ver qué se está generando
        # print(f"[INFO] Cleaned content: {cleaned_content[:200]}")  # Imprimir los primeros 200 caracteres

        with open(file_path, 'w') as f:
            f.write(cleaned_content)

        print(f"[INFO] Successfully cleaned {file_path}")
    except Exception as e:
        print(f"[ERROR] Failed to clean {file_path}: {e}")


    # Recorrer todos los archivos en el directorio
for filename in os.listdir(r'C:\Users\jon.ruizcarrillo\Desktop\Projects\TFM\inno-dashboard-assistant-2024\Data_Transformation\OpenAI_API\Data_Structuring\sample_json_reports'):
    if filename.endswith('.json'):
        file_path = os.path.join(r'C:\Users\jon.ruizcarrillo\Desktop\Projects\TFM\inno-dashboard-assistant-2024\Data_Transformation\OpenAI_API\Data_Structuring\sample_json_reports', filename)
        clean_json_file(file_path)  # Cargar el contenido del JSON
