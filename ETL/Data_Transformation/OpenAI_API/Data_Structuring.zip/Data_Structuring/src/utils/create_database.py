import argparse
import os
import json
from dotenv import load_dotenv
from tqdm import tqdm
from qdrant_client import QdrantClient
from qdrant_client.http import models
from PIL import Image
from openai import AzureOpenAI

from utils.database_utils import get_texts_and_images
from utils.images_utils import pil_image_to_base64
from utils.embedding_utils import get_embedding

#TODO: CHECK FOR DELETE
def create_database(texts_folder, images_folder):

    load_dotenv("../env/.env")

    API_KEY = os.getenv('API_KEY')
    ENDPOINT = os.getenv('ENDPOINT')
    DEPLOYMENT_NAME = os.getenv('DEPLOYMENT_NAME_EMBEDDING')

    COLLECTION_NAME = "dashboards"
    EMBEDDING_SIZE = 3072

    qdrant_client = QdrantClient("qdrant", port=6333)
    print("[INFO] Client created...")

    print("[INFO] Loading texts...")
    texts_and_images = get_texts_and_images(texts_folder, images_folder)

    print("[INFO] Loading the model...")
    client = AzureOpenAI(
        api_key=API_KEY,  
        api_version="2024-02-01",
        azure_endpoint = ENDPOINT
    )

    print("[INFO] Creating Qdrant data collection...")
    qdrant_client.create_collection(
        collection_name=COLLECTION_NAME,
        vectors_config=models.VectorParams(size=EMBEDDING_SIZE, distance=models.Distance.COSINE),
    )

    print("[INFO] Creating a data collection...")
    points = []
    for idx, (text, image_path) in tqdm(enumerate(texts_and_images), total=len(texts_and_images)):
        text_embeddings = get_embedding(client, text, DEPLOYMENT_NAME)

        # with open("./dataset/texts/1_01.txt", "r") as file:
        #     content = file.read()
        data = json.loads(text)

        title=data["title"]
        summary=data["summary"]

        image = Image.open(image_path)
        img_base64 = pil_image_to_base64(image)
        
        points.append(models.PointStruct(
            id=idx,
            vector=text_embeddings,
            payload={"title": title,
                     "summary": summary,
                     "text": text,
                     "img_base64": img_base64, 
                     "filename": os.path.basename(image_path),}
        ))

    print("[INFO] Uploading data records to data collection...")
    qdrant_client.upload_points(
        collection_name=COLLECTION_NAME,
        points=points,
    )

    print("[INFO] Successfully uploaded data records to data collection!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process image and text directories for Qdrant upload.")
    parser.add_argument("-t", "--texts", required=True, help="Path to the directory containing text files.")
    parser.add_argument("-i", "--images", required=True, help="Path to the directory containing image files.")

    args = parser.parse_args()
    texts_folder = args.texts
    images_folder = args.images

    create_database(texts_folder, images_folder)