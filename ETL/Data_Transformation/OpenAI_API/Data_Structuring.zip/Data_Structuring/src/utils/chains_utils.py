from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts.prompt import PromptTemplate
from jinja2 import Environment, FileSystemLoader, select_autoescape

jinja_env = Environment(
    loader=FileSystemLoader("backend/templates"),
    autoescape=select_autoescape()
)

def get_chain(llm, template_file):

    template = jinja_env.get_template(template_file)
    chat_answer_answer_prompt = template.render({})

    return PromptTemplate(input_variables=[], template=chat_answer_answer_prompt) | llm | StrOutputParser()