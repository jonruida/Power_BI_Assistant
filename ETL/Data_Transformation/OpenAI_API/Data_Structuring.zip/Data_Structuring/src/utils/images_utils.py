import base64
from io import BytesIO
from PIL import Image

def base64_to_pil_image(base64_str):
    image_data = base64.b64decode(base64_str)
    image = Image.open(BytesIO(image_data))
    return image

def pil_image_to_base64(pil_image):
    if pil_image.mode in ("RGBA", "P"):
        pil_image = pil_image.convert("RGB")
    
    buffered = BytesIO()
    pil_image.save(buffered, format="JPEG")
    return base64.b64encode(buffered.getvalue()).decode()

def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def resize_image(image, max_pixels):
    width, height = image.size
    if width * height > max_pixels:
        scaling_factor = (max_pixels / (width * height)) ** 0.5
        new_width = int(width * scaling_factor)
        new_height = int(height * scaling_factor)
        image = image.resize((new_width, new_height))
    return image