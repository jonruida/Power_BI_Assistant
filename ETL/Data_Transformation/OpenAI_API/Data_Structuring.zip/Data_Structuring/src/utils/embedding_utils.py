def get_embedding(client, model, text):
   text = text.replace("\n", " ")
   return client.embeddings.create(input = [text], model=model).data[0].embedding

def get_embedding_langchain(model, text):
   return model.embed_query(text)