import os
import json
from utils.images_utils import base64_to_pil_image

def get_texts(folder_path):
    texts = []
    for file in os.listdir(folder_path):
        if file.endswith(".txt"):  
            file_path = os.path.join(folder_path, file)
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
                texts.append((text, file))
    return texts

def get_texts_and_images(text_folder, images_folder):
    texts = []
    for file in os.listdir(text_folder):
        if file.endswith(".txt"):
            file_path = os.path.join(text_folder, file)
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read().strip()
                #TODO: NO SOLO PNGs
                image_filename = file.replace('.txt', '.png')
                image_path = os.path.join(images_folder, image_filename)
                if os.path.exists(image_path):
                    texts.append((text, image_path))
    return texts

def get_jsons_and_images(json_folder, images_folder):
    json_data = []
    image_extensions = [".png", ".jpg", ".jpeg", ".bmp"]

    for file in os.listdir(json_folder):
        if file.endswith(".json"):
            json_file_path = os.path.join(json_folder, file)
            with open(json_file_path, 'r', encoding='utf-8') as f:
                
                data = json.load(f)

                image_filename = os.path.splitext(file)[0]
                image_path = None

                for ext in image_extensions:
                    possible_image_path = os.path.join(images_folder, image_filename + ext)
                    if os.path.exists(possible_image_path):
                        image_path = possible_image_path
                        break

                if image_path:
                    json_data.append((data, image_path))
                else:
                    print(f"[WARNING] No matching image found for {file}")

    return json_data


def search_text(qdrant_client, collection, text_embeddings, limit=1):
    
    hits = qdrant_client.search(
        collection_name=collection,
        query_vector=text_embeddings,
        limit=limit
    )
    
    results = []
    for hit in hits:
        image_base64 = hit.payload["img_base64"]
        image = base64_to_pil_image(image_base64) 

        results.append({
            "id": hit.id,
            "score": hit.score,
            "filename": hit.payload["filename"],
            "title": hit.payload["title"],
            "summary": hit.payload["summary"],
            "data": hit.payload["json"],
            "image": image,
        })
    
    return results