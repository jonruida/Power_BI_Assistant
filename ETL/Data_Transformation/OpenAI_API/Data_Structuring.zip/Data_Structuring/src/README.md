## Structure of Vectors with Different Degrees of Granularity

The idea is to generate embeddings (vectors) to represent report data at different levels of granularity. This allows searching and analysis at different levels of detail, such as by complete reports, by pages within a report, and by individual elements (KPIs, tables, visualizations).

### Schema in Mermaid


```mermaid
graph TD
    A[Reporte Completo] -->|Combinar| B[Embedding del Reporte Completo]
    
    B -->|Por Página| C[Vectores por Páginas]
    C -->|Combinar| D[Embedding Combinado por Página]

    C --> E[KPIs de Página]
    C --> F[Visualizaciones de Página]
    C --> G[Tablas de Página]

    E -->|Generar| H[KPI 1 Embedding]
    E -->|Generar| I[KPI 2 Embedding]

    F -->|Generar| J[Visualización 1 Embedding]
    F -->|Generar| K[Visualización 2 Embedding]

    G -->|Generar| L[Tabla 1 Embedding]
    G -->|Generar| M[Tabla 2 Embedding]

    D -->|Subir| N[Subir Embedding Combinado por Página a Qdrant]
    B -->|Subir| O[Subir Embedding del Reporte Completo a Qdrant]
    
    H -->|Subir| P[Subir KPI 1 Embedding a Qdrant]
    I -->|Subir| Q[Subir KPI 2 Embedding a Qdrant]

    J -->|Subir| R[Subir Visualización 1 Embedding a Qdrant]
    K -->|Subir| S[Subir Visualización 2 Embedding a Qdrant]

    L -->|Subir| T[Subir Tabla 1 Embedding a Qdrant]
    M -->|Subir| U[Subir Tabla 2 Embedding a Qdrant]


```
## 

### Combined Vectors of the Complete Report:
At the global level, a vector is created that combines the KPIs, visualizations, tables and conclusions of the entire report.  
This is useful for general searches and global analysis.

### Page Vectors:
At the level of each page, vectors are generated for the KPIs, visualizations and tables detected on each page.  
Each page will have its own vector, with the combined elements of that page.

### Vectors for Individual Elements:
Each KPI, visualization and table on a page is indexed with its own vector, allowing detailed searches at the level of specific elements.

### Technical Considerations

### IDs and Dates:
All vectors associated with a report share the same report_id and date.  
Each page has a unique page number (page_number) that distinguishes vectors from different sections of the same report.

### Vector Database Insertion:
Vectors are inserted both at the combined level (full report and full page) and at the individual level (elements of each page).  
This offers flexibility in querying and analysis.

## Insertion Flow
### Complete Reports: Insert the vector that combines all elements of the report.
###By Page: Insert vectors that combine all KPIs, visualizations, and tables of each page.
###By Individual Elements: Insert specific vectors for each KPI, visualization, and table, maintaining the reference to the original page and report.

## Example JSON Structure for Each Page
```json
{
  “report_id": ‘report_123’,
  “date": ‘2024-09-23’,
  “page": 1,
  “detected_elements": {
    “KPIs": [
      {
        “kpi_title": ‘sales_growth’,
        “kpi_value": ‘15%’,
        “kpi_reference": ‘10% target’,
        “insights": ”Sales growth is exceeding the target by 5%”
      }
    ],
    “charts": [
      {
        “visualization_title": ‘Monthly Sales Chart’,
        “visualization_type": ‘Line Chart’,
        “metrics_displayed“: [”Sales”, ‘Revenue’ ],
        “values“: [”500K”, ‘1M’],
        “insights": ”Sales are trending upwards.”
      }
    ],
    “tables": [
      {
        “table_title": ‘Revenue Breakdown’,
        “columns": [ ‘Product’, ‘Revenue’ ],
        “rows": [
          ["Prod

