import os
from langchain_openai import OpenAIEmbeddings
from qdrant_client import QdrantClient
from qdrant_client.http import models
from qdrant_client.models import Distance, VectorParams
import json
from tqdm import tqdm
from dotenv import load_dotenv
import re  
# Cargar el archivo .env
load_dotenv('/app/.env')  # Asegúrate de que la ruta sea correcta

class DatabaseCreator:
    def __init__(self, texts_folder):
        self.texts_folder = texts_folder
        self.collection_name = "dashboards"
        self.embedding_size = 1536  # OpenAI's text-embedding-ada-002 size
        # Inicializa el cliente de Qdrant
        self.qdrant_client = QdrantClient("qdrant", port=6333)
        print("[INFO] Client created...")

        # Cargar los textos
        print("[INFO] Loading texts...")
        self.jsons = self.load_json_data()

        # Inicializa Langchain con OpenAI Embeddings
        print("[INFO] Loading the OpenAI model for embeddings...")
        self.embedding_model = OpenAIEmbeddings(openai_api_key=os.getenv('OPENAI_API_KEY'))


    def load_json_data(self):
        json_files = [f for f in os.listdir(self.texts_folder) if f.endswith('.json')]
        json_data = []

        for json_file in json_files:
            file_path = os.path.join(self.texts_folder, json_file)
            try:
                # Limpieza inicial del archivo antes de cargar el JSON
                self.clean_json_file(file_path)

                with open(file_path, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        json_data.extend(data)
                    elif isinstance(data, dict):
                        json_data.append(data)
                    else:
                        print(f"[WARNING] Unexpected data format in {json_file}: {type(data)}")
            except json.JSONDecodeError as e:
                print(f"[ERROR] Failed to load {json_file}: {e}")
            except Exception as e:
                print(f"[ERROR] Unexpected error loading {json_file}: {e}")

        return json_data

    def clean_json_file(self, file_path):
        print(f"[INFO] Cleaning JSON file: {file_path}")
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                cleaned_content = re.sub(r'```json|```', '', content)
                cleaned_content = cleaned_content.strip().strip('"')
                cleaned_content = cleaned_content.replace('\\n', ' ').strip()
                cleaned_content = cleaned_content.replace('\\', '').strip()


            # Imprimir el contenido limpio para ver qué se está generando
            # print(f"[INFO] Cleaned content: {cleaned_content[:200]}")  # Imprimir los primeros 200 caracteres

            with open(file_path, 'w') as f:
                f.write(cleaned_content)

            print(f"[INFO] Successfully cleaned {file_path}")
        except Exception as e:
            print(f"[ERROR] Failed to clean {file_path}: {e}")


    def create_collection(self):
        try:
            # Verificar si la colección ya existe
            self.qdrant_client.get_collection(self.collection_name)
            print(f"[INFO] La colección '{self.collection_name}' ya existe. No se creará de nuevo.")
        except Exception as e:
            # Si la colección no existe, se crea
            print("[INFO] Creating Qdrant data collection...")
            self.qdrant_client.create_collection(
                collection_name=self.collection_name,
                vectors_config=models.VectorParams(size=self.embedding_size, distance=models.Distance.COSINE),
            )

    def process_and_upload_data(self):
        print("[INFO] Processing data and uploading to Qdrant...")
        points = []  # Lista para almacenar los puntos a subir a Qdrant
        report_texts = {}  # Diccionario para almacenar textos combinados por report_id

        for idx, report in tqdm(enumerate(self.jsons), total=len(self.jsons)):
            report_id = report.get("report_id")
            page_number = report.get("page")
            print(f"[DEBUG] Report ID: {report_id}, Page: {page_number}")

            # Combinar el texto de KPIs, gráficos y tablas
            detected_elements = report.get('detected_elements', {})
            kpis_text = "\n".join([f"KPI Title: {kpi['kpi_title']}, Value: {kpi['kpi_value']}, Insights: {kpi['insights']}"
                                   for kpi in detected_elements.get("KPIs", [])])
            charts_text = "\n".join([f"Chart Title: {chart['visualization_title']}, Type: {chart['visualization_type']}, Insights: {chart['insights']}"
                                     for chart in detected_elements.get("charts", [])])
            tables_text = "\n".join([f"Table Title: {table['table_title']}, Columns: {', '.join(table['columns'])}, Insights: {table['insight']}"
                                     for table in detected_elements.get("tables", [])])

            combined_page_text = kpis_text + "\n" + charts_text + "\n" + tables_text
            report_texts.setdefault(report_id, "")
            report_texts[report_id] += combined_page_text

            combined_page_embedding = self.embedding_model.embed_documents([combined_page_text])[0]
            points.append(models.PointStruct(
                id=idx * 5,
                vector=combined_page_embedding,
                payload={
                    "type": "CombinedPage",
                    "report_id": report_id,
                    "date": report.get("date"),
                    "page": page_number,
                    "final_conclusions": report.get("final_conclusions"),
                }
            ))

            # Embeddings para KPIs, gráficos y tablas
            if kpis_text:
                kpis_embedding = self.embedding_model.embed_documents([kpis_text])[0]
                points.append(models.PointStruct(
                    id=idx * 5 + 1,
                    vector=kpis_embedding,
                    payload={
                        "type": "KPI",
                        "report_id": report_id,
                        "date": report.get("date"),
                        "page": page_number,
                        "final_conclusions": report.get("final_conclusions"),
                    }
                ))
            if charts_text:
                charts_embedding = self.embedding_model.embed_documents([charts_text])[0]
                points.append(models.PointStruct(
                    id=idx * 5 + 2,
                    vector=charts_embedding,
                    payload={
                        "type": "Chart",
                        "report_id": report_id,
                        "date": report.get("date"),
                        "page": page_number,
                        "final_conclusions": report.get("final_conclusions"),
                    }
                ))
            if tables_text:
                tables_embedding = self.embedding_model.embed_documents([tables_text])[0]
                points.append(models.PointStruct(
                    id=idx * 5 + 3,
                    vector=tables_embedding,
                    payload={
                        "type": "Table",
                        "report_id": report_id,
                        "date": report.get("date"),
                        "page": page_number,
                        "final_conclusions": report.get("final_conclusions"),
                    }
                ))

        # Embeddings combinados por informe completo
        for report_id, report_text in report_texts.items():
            combined_report_embedding = self.embedding_model.embed_documents([report_text])[0]
            points.append(models.PointStruct(
                id=len(points),
                vector=combined_report_embedding,
                payload={
                    "type": "CombinedReport",
                    "report_id": report_id,
                    "date": report.get("date"),
                    "final_conclusions": report.get("final_conclusions"),
                }
            ))

         # Resumen de los datos que se van a cargar
        print(f"[INFO] Total points to upload: {len(points)}")
        kpi_count = sum(1 for point in points if point.payload["type"] == "KPI")
        chart_count = sum(1 for point in points if point.payload["type"] == "Chart")
        table_count = sum(1 for point in points if point.payload["type"] == "Table")
        combined_report_count = sum(1 for point in points if point.payload["type"] == "CombinedReport")

        print(f"[INFO] Total KPIs: {kpi_count}")
        print(f"[INFO] Total Charts: {chart_count}")
        print(f"[INFO] Total Tables: {table_count}")
        print(f"[INFO] Total Combined Reports: {combined_report_count}")

        # Imprimir ejemplos de los primeros puntos
        for point in points[:5]:  # Imprimir solo los primeros 5 puntos como ejemplo
            print(f"[INFO] Point ID: {point.id}, Type: {point.payload['type']}, Report ID: {point.payload['report_id']}")



        print("[INFO] Uploading data records to Qdrant...")
        self.qdrant_client.upload_points(
            collection_name=self.collection_name,
            points=points,
        )
        print("[INFO] Successfully uploaded data records!")

    def run(self):
        self.create_collection()
        self.process_and_upload_data()


# Ruta a los textos en formato JSON
texts_folder = "/app/images"  # Asegúrate de que esta ruta sea correcta

db_creator = DatabaseCreator(texts_folder)
db_creator.run()
