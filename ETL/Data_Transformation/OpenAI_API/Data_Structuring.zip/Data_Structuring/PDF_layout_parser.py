import os
import os
import base64
import json
import re
import requests
from dotenv import load_dotenv
from tqdm import tqdm
from langchain_community.document_loaders import PyPDFLoader
from pdf2image import convert_from_path
import openai
def pdf_to_text(pdf_path, output_dir):
    """Convierte todas las páginas de un PDF a texto y guarda cada página en un archivo separado."""
    loader = PyPDFLoader(pdf_path, extraction_mode="layout")
    pages = loader.lazy_load()

    pdf_text_contents = []
    
    # Asegurarse de que el directorio de salida exista
    os.makedirs(output_dir, exist_ok=True)

    for idx, doc in enumerate(pages):
        page_content = doc.page_content  # Almacena el contenido de cada página como un string
        pdf_text_contents.append(page_content)

        # Guardar el contenido de la página en un archivo de texto
        output_file_path = os.path.join(output_dir, f'page_{idx + 1}.txt')
        with open(output_file_path, 'w', encoding='utf-8') as f:
            f.write(page_content)  # Escribir el contenido de la página en el archivo

    return pdf_text_contents
pdf_to_text(r'C:\Users\jon.ruizcarrillo\Desktop\Projects\TFM\inno-dashboard-assistant-2024\Data_Transformation\OpenAI_API\Data_Structuring\Eagle_Ventas.pdf',r'C:\Users\jon.ruizcarrillo\Desktop\Projects\TFM\inno-dashboard-assistant-2024\Data_Transformation\OpenAI_API\Data_Structuring\src\texts')